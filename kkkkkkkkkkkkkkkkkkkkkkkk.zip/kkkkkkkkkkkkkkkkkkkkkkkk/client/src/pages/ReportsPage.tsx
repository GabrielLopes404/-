import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Download, HelpCircle } from "lucide-react";

export default function ReportsPage() {
  const [startDate, setStartDate] = useState("01/11/2025");
  const [endDate, setEndDate] = useState("30/11/2025");

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Relatórios</h1>
          <p className="text-muted-foreground">
            Gere relatórios personalizados das suas finanças
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Filtros de Relatório</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Data inicial</Label>
                <Input 
                  type="text" 
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  placeholder="DD/MM/AAAA"
                />
              </div>

              <div className="space-y-2">
                <Label>Data final</Label>
                <Input 
                  type="text" 
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  placeholder="DD/MM/AAAA"
                />
              </div>

              <div className="space-y-2">
                <Label>Categorias</Label>
                <Select defaultValue="all">
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    <SelectItem value="income">Receitas</SelectItem>
                    <SelectItem value="expenses">Despesas</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Contatos</Label>
                <Select defaultValue="all">
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Tags / marcações</Label>
                <Select defaultValue="all">
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Modos de pagamento</Label>
                <Select defaultValue="all">
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-3 border-t pt-4">
              <Label>Incluir lançamentos</Label>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox id="paid" defaultChecked />
                  <label
                    htmlFor="paid"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Pagos
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="unpaid" defaultChecked />
                  <label
                    htmlFor="unpaid"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Não pagos
                  </label>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button className="gap-2">
                <FileText className="h-4 w-4" />
                Mostrar por pagamento
              </Button>
              <Button variant="outline" className="gap-2">
                <FileText className="h-4 w-4" />
                Mostrar por competência
              </Button>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="cashflow" className="w-full">
          <TabsList>
            <TabsTrigger value="cashflow">Fluxo de Caixa</TabsTrigger>
            <TabsTrigger value="dre">Resultados (DRE)</TabsTrigger>
            <TabsTrigger value="extract">Extrato</TabsTrigger>
            <TabsTrigger value="income">Despesas/Receitas</TabsTrigger>
          </TabsList>

          <TabsContent value="cashflow" className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Fluxo de Caixa</CardTitle>
                  <Button variant="outline" className="gap-2">
                    <Download className="h-4 w-4" />
                    Exportar
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border rounded-lg p-6">
                    <div className="flex items-center gap-2 mb-4">
                      <HelpCircle className="h-5 w-5 text-muted-foreground" />
                      <h3 className="font-semibold">Receita bruta</h3>
                    </div>
                    <div className="text-3xl font-bold text-green-600">R$ 850,00</div>
                  </div>

                  <div className="border rounded-lg p-6">
                    <div className="flex items-center gap-2 mb-4">
                      <HelpCircle className="h-5 w-5 text-muted-foreground" />
                      <h3 className="font-semibold">Impostos</h3>
                    </div>
                    <div className="text-3xl font-bold text-red-600">R$ 0,00</div>
                  </div>

                  <div className="border rounded-lg p-6 bg-primary/5">
                    <div className="flex items-center gap-2 mb-4">
                      <HelpCircle className="h-5 w-5 text-primary" />
                      <h3 className="font-semibold">RESULTADO DO EXERCÍCIO</h3>
                    </div>
                    <div className="text-3xl font-bold text-primary">R$ 850,00 (100%)</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="dre" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-muted-foreground py-12">
                  Selecione os filtros e clique em "Mostrar por competência" para visualizar o DRE
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="extract" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-muted-foreground py-12">
                  Nenhum extrato disponível para o período selecionado
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="income" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-muted-foreground py-12">
                  Configure os filtros para visualizar despesas e receitas
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
