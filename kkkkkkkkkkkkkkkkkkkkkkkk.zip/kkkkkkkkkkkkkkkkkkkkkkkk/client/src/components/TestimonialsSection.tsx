import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Star, Quote } from "lucide-react";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const testimonials = [
  {
    name: "Maria Silva",
    role: "CEO",
    company: "TechStart Solutions",
    content: "O LUCREI transformou completamente nossa gestão financeira. Conseguimos reduzir em 70% o tempo gasto com administração e temos visibilidade total do nosso fluxo de caixa.",
    rating: 5
  },
  {
    name: "Roberto Santos",
    role: "Diretor Financeiro",
    company: "Construtora Moderna",
    content: "Finalmente encontramos um sistema que é ao mesmo tempo poderoso e fácil de usar. A automação de cobranças nos economizou incontáveis horas todo mês.",
    rating: 5
  },
  {
    name: "Ana Costa",
    role: "Fundadora",
    company: "Studio Criativo",
    content: "Como freelancer, sempre tive dificuldade com organização financeira. O LUCREI me deu controle total e profissionalismo nas minhas cobranças. Recomendo de olhos fechados!",
    rating: 5
  }
];

export default function TestimonialsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section id="depoimentos" className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-background" />
      
      <div ref={ref} className="max-w-[1280px] mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-sm font-medium text-primary mb-4"
          >
            <Quote className="h-4 w-4" />
            Depoimentos
          </motion.div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-semibold mb-4 bg-gradient-to-r from-foreground via-foreground to-foreground/70 bg-clip-text text-transparent" data-testid="text-testimonials-title">
            Quem usa, aprova
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto" data-testid="text-testimonials-subtitle">
            Veja o que nossos clientes têm a dizer sobre o LUCREI
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.2 + index * 0.15, duration: 0.6 }}
              whileHover={{ y: -8 }}
            >
              <Card 
                className="p-8 h-full hover-elevate transition-all duration-500 border-primary/10 backdrop-blur-sm bg-card/50 relative overflow-hidden group"
                data-testid={`card-testimonial-${index}`}
              >
                <motion.div
                  className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-primary/5 to-transparent rounded-full blur-2xl"
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.3, 0.5, 0.3],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />

                <motion.div 
                  className="flex gap-1 mb-6 relative z-10"
                  initial={{ opacity: 0 }}
                  animate={isInView ? { opacity: 1 } : {}}
                  transition={{ delay: 0.4 + index * 0.15 }}
                >
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={isInView ? { opacity: 1, scale: 1 } : {}}
                      transition={{ delay: 0.5 + index * 0.15 + i * 0.05 }}
                    >
                      <Star className="h-5 w-5 fill-yellow-500 text-yellow-500" />
                    </motion.div>
                  ))}
                </motion.div>
                
                <div className="relative mb-8">
                  <Quote className="absolute -top-2 -left-2 h-8 w-8 text-primary/20" />
                  <p className="text-muted-foreground leading-relaxed relative z-10 pl-6" data-testid={`text-testimonial-content-${index}`}>
                    {testimonial.content}
                  </p>
                </div>

                <div className="flex items-center gap-4 relative z-10">
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    transition={{ type: "spring", stiffness: 300, damping: 10 }}
                  >
                    <Avatar className="h-14 w-14 border-2 border-primary/20 bg-gradient-to-br from-primary/20 to-primary/10">
                      <AvatarFallback className="bg-transparent text-foreground font-semibold">{testimonial.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                  </motion.div>
                  <div>
                    <div className="font-semibold group-hover:text-primary transition-colors" data-testid={`text-testimonial-name-${index}`}>
                      {testimonial.name}
                    </div>
                    <div className="text-sm text-muted-foreground" data-testid={`text-testimonial-role-${index}`}>
                      {testimonial.role}, {testimonial.company}
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
